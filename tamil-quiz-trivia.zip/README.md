# Tamil Quiz & Trivia

A responsive, single-page Tamil trivia app built with plain HTML, CSS and JavaScript. No build step or external dependencies are required.

## Run it
1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. Enter a username, choose a category and difficulty, then start the quiz.

## Features
- Username welcome form and category/difficulty filters.
- Ten multiple-choice questions across Tamil literature, cinema, history and culture.
- Immediate correct/incorrect feedback, progress bar and live scoring.
- Final score, percentage, correct/missed count and elapsed time.
- Local leaderboard sorted by score descending, then earliest timestamp for ties.
- Scores persist in this browser using `localStorage`; reset is available on the leaderboard.
- Responsive mobile layout, keyboard focus styles and reduced-motion support.

## Notes
- This is a client-only demo. Scores are stored on the current browser/device and are not synced across devices or protected against manual editing.
- If your browser blocks local storage for local files, run a simple static server or open the file through a local web server.
- Question content is intentionally self-contained in `index.html`; edit the `questions` array to add or revise trivia.
